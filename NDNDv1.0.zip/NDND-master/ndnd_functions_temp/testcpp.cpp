#include <iostream>
using namespace std;

int main () {
  // for loop execution
  for( int a = 10; a < 20; a = a + 1 ) {
    cout << "value of a: " << a << endl;
  }
  
  return 0;
}